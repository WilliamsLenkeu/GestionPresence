# GestionPresence
📚 Suivi d'assiduité étudiante en HTML, CSS, et PHP ! Gérez facilement la présence des étudiants avec une interface intuitive, des graphiques interactifs et une gestion efficace des données. Simplifiez votre suivi de présence avec ce projet open-source ! 💻📊 #GestionAssiduite #EducationTech
